<?php
session_start();
require_once "../config/session_timeout.php";

/* 🔒 MUST BE LOGGED IN */
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

/* 🔒 MUST BE ADMIN */
if ($_SESSION['role'] !== 'admin') {
    http_response_code(403);
    die("⛔ Access Denied. Admins only.");
}

require_once "../config/db.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard | EventRia</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Original Theme -->
<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">

    <!-- 🔹 TITLE -->
    <h1 class="fw-bold text-dark mb-3">
        👑 Admin Dashboard
    </h1>

    <!-- 🔹 WELCOME TEXT -->
    <p class="fs-5 text-dark mb-5">
        Welcome, <strong><?= htmlspecialchars($_SESSION['name']) ?></strong>.  
        Use the options below to manage the system.
    </p>

    <!-- 🔹 ACTION CARDS -->
    <div class="row g-4">

        <!-- MANAGE USERS -->
        <div class="col-md-4">
            <a href="manage_users.php" class="text-decoration-none">
                <div class="card shadow-sm h-100 border-0 admin-card">
                    <div class="card-body text-center p-4">
                        <div class="fs-1 mb-3">👥</div>
                        <h4 class="fw-bold text-dark">Manage Users</h4>
                        <p class="text-muted mt-2">
                            Edit, suspend, or delete system users
                        </p>
                    </div>
                </div>
            </a>
        </div>

        <!-- MANAGE EVENTS -->
        <div class="col-md-4">
            <a href="manage_events.php" class="text-decoration-none">
                <div class="card shadow-sm h-100 border-0 admin-card">
                    <div class="card-body text-center p-4">
                        <div class="fs-1 mb-3">📅</div>
                        <h4 class="fw-bold text-dark">Manage Events</h4>
                        <p class="text-muted mt-2">
                            Approve, highlight, or archive events
                        </p>
                    </div>
                </div>
            </a>
        </div>

        <!-- GENERATE REPORTS -->
        <div class="col-md-4">
            <a href="reports.php" class="text-decoration-none">
                <div class="card shadow-sm h-100 border-0 admin-card">
                    <div class="card-body text-center p-4">
                        <div class="fs-1 mb-3">📊</div>
                        <h4 class="fw-bold text-dark">Generate Reports</h4>
                        <p class="text-muted mt-2">
                            Monthly & category-based analytics
                        </p>
                    </div>
                </div>
            </a>
        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
