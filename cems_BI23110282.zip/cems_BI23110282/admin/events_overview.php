<?php
session_start();
require_once "../config/session_timeout.php";
require_once "../config/db.php";

/* 🔒 ADMIN ONLY */
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    die("⛔ Access Denied");
}

/* ALLOWED TYPES */
$allowedTypes = [
    "Workshop",
    "Seminar",
    "Competition",
    "Festival",
    "Sport",
    "Course"
];

$type = $_GET['type'] ?? 'all';

/* BASE QUERY */
$sql = "SELECT id, event_name, type, event_date, venue FROM events";

/* FILTER */
if ($type !== 'all' && in_array($type, $allowedTypes)) {
    $sql .= " WHERE type = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $type);
} else {
    $stmt = $conn->prepare($sql);
}

$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Total Events | Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">

<h3 class="mb-4">📅 All Events</h3>

<!-- FILTER -->
<form class="row g-2 mb-4">
    <div class="col-md-4">
        <select name="type" class="form-select" onchange="this.form.submit()">
            <option value="all">All Categories</option>
            <?php foreach ($allowedTypes as $t): ?>
                <option value="<?= $t ?>" <?= $type === $t ? 'selected' : '' ?>>
                    <?= $t ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
</form>

<table class="table table-bordered table-striped">
<thead class="table-dark">
<tr>
    <th>#</th>
    <th>Event Name</th>
    <th>Category</th>
    <th>Date</th>
    <th>Venue</th>
</tr>
</thead>
<tbody>

<?php if ($result->num_rows === 0): ?>
<tr>
    <td colspan="5" class="text-center text-muted">No events found.</td>
</tr>
<?php endif; ?>

<?php $i=1; while($e=$result->fetch_assoc()): ?>
<tr>
    <td><?= $i++ ?></td>
    <td><?= htmlspecialchars($e['event_name']) ?></td>
    <td><?= $e['type'] ?></td>
    <td><?= $e['event_date'] ?></td>
    <td><?= htmlspecialchars($e['venue']) ?></td>
</tr>
<?php endwhile; ?>

</tbody>
</table>


</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
