<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access denied");
}

$month = $_GET['month'] ?? '';
$type  = $_GET['type'] ?? '';

$sql = "
SELECT 
    e.event_name,
    e.type,
    e.event_date,
    COUNT(r.id) AS total_registered,
    SUM(CASE WHEN r.attendance = 'present' THEN 1 ELSE 0 END) AS total_attended
FROM events e
LEFT JOIN registrations r ON e.id = r.event_id
WHERE 1
";

$params = [];
$types  = "";

if (!empty($month)) {
    $sql .= " AND MONTH(e.event_date) = ?";
    $params[] = $month;
    $types .= "i";
}

if (!empty($type)) {
    $sql .= " AND e.type = ?";
    $params[] = $type;
    $types .= "s";
}

$sql .= " GROUP BY e.id ORDER BY e.event_date ASC";

$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$today = date('Y-m-d');
?>
<!DOCTYPE html>
<html>
<head>
<title>Event Report</title>
<style>
body { font-family: Arial; }
table { width: 100%; border-collapse: collapse; }
th, td { border: 1px solid #000; padding: 8px; }
th { background: #198754; color: white; }
</style>
</head>
<body onload="window.print()">

<h2>📊 Event Participation Report</h2>

<table>
<tr>
<th>Event</th>
<th>Category</th>
<th>Date</th>
<th>Registered</th>
<th>Attended</th>
<th>Status</th>
</tr>

<?php while ($row = $result->fetch_assoc()):
$status = ($row['event_date'] < $today) ? "Done" : "Ongoing";
?>
<tr>
<td><?= htmlspecialchars($row['event_name']) ?></td>
<td><?= $row['type'] ?></td>
<td><?= $row['event_date'] ?></td>
<td><?= $row['total_registered'] ?></td>
<td><?= $row['total_attended'] ?></td>
<td><?= $status ?></td>
</tr>
<?php endwhile; ?>

</table>

</body>
</html>
