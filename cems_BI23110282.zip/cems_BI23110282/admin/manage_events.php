<?php
session_start();

require_once "../config/session_timeout.php";
require_once "../config/db.php";

/* =========================
   ADMIN ACCESS CHECK
========================= */
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("⛔ Access Denied");
}

/* =========================
   HANDLE ACTIONS
========================= */
if (isset($_GET['action'], $_GET['id'])) {

    $id = (int)$_GET['id'];

    /* =========================
       APPROVE EVENT + NOTIFY
    ========================= */
    if ($_GET['action'] === 'approve') {

        $stmt = $conn->prepare("
            UPDATE events 
            SET status='approved' 
            WHERE id=? AND status='pending'
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {

            // get event + creator
            $eventStmt = $conn->prepare("
                SELECT event_name, user_id 
                FROM events WHERE id=?
            ");
            $eventStmt->bind_param("i", $id);
            $eventStmt->execute();
            $event = $eventStmt->get_result()->fetch_assoc();
            $eventStmt->close();

            // notify creator
            if ($event) {
                $notif = $conn->prepare("
                    INSERT INTO notifications (user_id, title, message, type)
                    VALUES (?, ?, ?, 'approval')
                ");

                $title = "Event Approved ✅";
                $message = "Your event '{$event['event_name']}' has been approved.";

                $notif->bind_param("iss", $event['user_id'], $title, $message);
                $notif->execute();
                $notif->close();
            }
        }

        $stmt->close();
    }

    /* =========================
       REJECT EVENT + NOTIFY
    ========================= */
    if ($_GET['action'] === 'reject') {

        $stmt = $conn->prepare("
            UPDATE events SET status='rejected' WHERE id=?
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        // notify creator
        $event = $conn->query("
            SELECT event_name, user_id FROM events WHERE id=$id
        ")->fetch_assoc();

        if ($event) {
            $notif = $conn->prepare("
                INSERT INTO notifications (user_id, title, message, type)
                VALUES (?, ?, ?, 'approval')
            ");

            $title = "Event Rejected ❌";
            $message = "Your event '{$event['event_name']}' was rejected. Please review.";

            $notif->bind_param("iss", $event['user_id'], $title, $message);
            $notif->execute();
            $notif->close();
        }
    }

    /* =========================
       ARCHIVE EVENT
    ========================= */
    if ($_GET['action'] === 'archive') {
        $stmt = $conn->prepare("
            UPDATE events SET status='archived' WHERE id=?
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    }

    /* =========================
       HIGHLIGHT EVENT
    ========================= */
    if ($_GET['action'] === 'highlight') {
        $stmt = $conn->prepare("
            UPDATE events SET highlighted=1 
            WHERE id=? AND status='approved'
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: manage_events.php");
    exit;
}

/* =========================
   FETCH EVENTS
========================= */
$events = $conn->query("
    SELECT id, event_name, type, status, highlighted
    FROM events
    ORDER BY 
        CASE status
            WHEN 'pending' THEN 1
            WHEN 'approved' THEN 2
            ELSE 3
        END, event_date DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Events | Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">

<h3 class="mb-4 system-title">📅 Manage Events</h3>

<div class="card shadow-sm">
<div class="card-body">

<div class="table-responsive">
<table class="table table-bordered align-middle themed-table">

<thead class="table-dark">
<tr>
<th>#</th>
<th>Event</th>
<th>Category</th>
<th>Status</th>
<th>Highlighted</th>
<th style="width:300px;">Actions</th>
</tr>
</thead>

<tbody>
<?php $i = 1; while ($e = $events->fetch_assoc()): ?>
<tr>

<td><?= $i++ ?></td>

<td class="fw-semibold"><?= htmlspecialchars($e['event_name']) ?></td>
<td><?= htmlspecialchars($e['type']) ?></td>

<td>
<?php if ($e['status'] === 'pending'): ?>
<span class="badge bg-warning text-dark">Pending</span>
<?php elseif ($e['status'] === 'approved'): ?>
<span class="badge bg-success">Approved</span>
<?php elseif ($e['status'] === 'rejected'): ?>
<span class="badge bg-danger">Rejected</span>
<?php else: ?>
<span class="badge bg-secondary">Archived</span>
<?php endif; ?>
</td>

<td><?= $e['highlighted'] ? '⭐ Yes' : 'No' ?></td>

<td>
<div class="d-flex gap-2 flex-wrap">

<?php if ($e['status'] === 'pending'): ?>
<a href="?action=approve&id=<?= $e['id'] ?>"
   class="btn btn-sm btn-success"
   onclick="return confirm('Approve this event?')">
✔ Approve
</a>

<a href="?action=reject&id=<?= $e['id'] ?>"
   class="btn btn-sm btn-danger"
   onclick="return confirm('Reject this event?')">
✖ Reject
</a>
<?php endif; ?>

<?php if ($e['status'] === 'approved' && !$e['highlighted']): ?>
<a href="?action=highlight&id=<?= $e['id'] ?>"
   class="btn btn-sm btn-info"
   onclick="return confirm('Highlight this event?')">
⭐ Highlight
</a>
<?php endif; ?>

<?php if ($e['status'] !== 'archived'): ?>
<a href="?action=archive&id=<?= $e['id'] ?>"
   class="btn btn-sm btn-secondary"
   onclick="return confirm('Archive this event?')">
🗄 Archive
</a>
<?php endif; ?>

</div>
</td>

</tr>
<?php endwhile; ?>
</tbody>

</table>
</div>

</div>
</div>

<a href="../admin/admin.php" class="btn btn-outline-secondary mt-4">
⬅ Back to Dashboard
</a>

</div>

</body>
</html>
