<?php
session_start();
require_once "../config/session_timeout.php";
require_once "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("⛔ Access Denied");
}

/* Handle actions */
if (isset($_GET['action'], $_GET['id'])) {
    $id = (int)$_GET['id'];

    if ($_GET['action'] === 'suspend') {
        $conn->query("UPDATE users SET status='suspended' WHERE id=$id");
    }
    if ($_GET['action'] === 'activate') {
        $conn->query("UPDATE users SET status='active' WHERE id=$id");
    }
    if ($_GET['action'] === 'delete') {
        $conn->query("DELETE FROM users WHERE id=$id");
    }
}

$users = $conn->query("SELECT id, name, email, role, status FROM users");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Users | Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">
<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">

    <!-- PAGE HEADER -->
    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body bg-success text-white rounded">
            <h2 class="fw-bold mb-1 text-white">👥 Manage Users</h2>
            <p class="mb-0">
                Activate, suspend, or remove system users
            </p>
        </div>
    </div>

    <!-- USERS TABLE -->
    <div class="card shadow-sm border-0">
        <div class="card-body">

            <table class="table align-middle table-hover">
                <thead class="table-success">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>

                <tbody>
                <?php $i = 1; while ($u = $users->fetch_assoc()): ?>
                    <tr>
                        <td><?= $i++ ?></td>

                        <td class="fw-semibold">
                            <?= htmlspecialchars($u['name']) ?>
                        </td>

                        <td><?= htmlspecialchars($u['email']) ?></td>

                        <td>
                            <span class="badge bg-secondary">
                                <?= ucfirst($u['role']) ?>
                            </span>
                        </td>

                        <td>
                            <?php if ($u['status'] === 'active'): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Suspended</span>
                            <?php endif; ?>
                        </td>

                        <td class="text-center">
                            <?php if ($u['status'] === 'active'): ?>
                                <a href="?action=suspend&id=<?= $u['id'] ?>"
                                   class="btn btn-outline-warning btn-sm">
                                   Suspend
                                </a>
                            <?php else: ?>
                                <a href="?action=activate&id=<?= $u['id'] ?>"
                                   class="btn btn-outline-success btn-sm">
                                   Activate
                                </a>
                            <?php endif; ?>

                            <a href="?action=delete&id=<?= $u['id'] ?>"
                               class="btn btn-outline-danger btn-sm"
                               onclick="return confirm('Are you sure you want to delete this user?')">
                               Delete
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>

            </table>

        </div>
    </div>

</div>
</body>
</html>
