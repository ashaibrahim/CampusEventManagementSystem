<?php
session_start();
require_once "../config/session_timeout.php";
require_once "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("⛔ Access Denied");
}

$eventId = $_GET['event'] ?? 'all';

$sql = "
SELECT u.name, u.email, e.event_name
FROM registrations r
JOIN users u ON r.user_id = u.id
JOIN events e ON r.event_id = e.id
";

if ($eventId !== 'all') {
    $sql .= " WHERE e.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $eventId);
} else {
    $stmt = $conn->prepare($sql);
}
$stmt->execute();
$result = $stmt->get_result();

$events = $conn->query("SELECT id, event_name FROM events");
?>
<!DOCTYPE html>
<html>
<head>
<title>Total Participants | Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">
<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">
<h3>👥 Event Participants</h3>

<form class="row g-2 mb-3">
<div class="col-md-5">
<select name="event" class="form-select" onchange="this.form.submit()">
<option value="all">All Events</option>
<?php while($e=$events->fetch_assoc()): ?>
<option value="<?= $e['id'] ?>" <?= $eventId==$e['id']?'selected':'' ?>>
<?= htmlspecialchars($e['event_name']) ?>
</option>
<?php endwhile; ?>
</select>
</div>
</form>

<table class="table table-bordered">
<thead class="table-dark">
<tr>
<th>#</th><th>Name</th><th>Email</th><th>Event</th>
</tr>
</thead>
<tbody>
<?php $i=1; while($p=$result->fetch_assoc()): ?>
<tr>
<td><?= $i++ ?></td>
<td><?= htmlspecialchars($p['name']) ?></td>
<td><?= htmlspecialchars($p['email']) ?></td>
<td><?= htmlspecialchars($p['event_name']) ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</body>
</html>
