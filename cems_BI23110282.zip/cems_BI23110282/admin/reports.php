<?php
session_start();
require_once "../config/session_timeout.php";
require_once "../config/db.php";

/* 🔒 ADMIN ONLY */
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("⛔ Access Denied");
}

/* =========================
   FILTER INPUTS
========================= */
$month = $_GET['month'] ?? '';
$type  = $_GET['type'] ?? '';

/* =========================
   BUILD SQL
========================= */
$sql = "
SELECT 
    e.id,
    e.event_name,
    e.type,
    e.event_date,
    COUNT(r.id) AS total_registered,
    SUM(CASE WHEN r.attendance = 'present' THEN 1 ELSE 0 END) AS total_attended
FROM events e
LEFT JOIN registrations r ON e.id = r.event_id
WHERE 1
";

$params = [];
$types  = "";

if (!empty($month)) {
    $sql .= " AND MONTH(e.event_date) = ?";
    $params[] = $month;
    $types .= "i";
}

if (!empty($type)) {
    $sql .= " AND e.type = ?";
    $params[] = $type;
    $types .= "s";
}

$sql .= "
GROUP BY e.id
ORDER BY e.event_date ASC
";

$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Event Reports | Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">
<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">

<h3 class="mb-4">📊 Event Participation Reports</h3>

<!-- =========================
     FILTER FORM
========================= -->
<form method="GET" class="row g-3 mb-4">

    <div class="col-md-3">
        <label class="form-label">Month</label>
        <input type="number"
               name="month"
               min="1"
               max="12"
               value="<?= htmlspecialchars($month) ?>"
               class="form-control"
               placeholder="1 - 12">
    </div>

    <div class="col-md-4">
        <label class="form-label">Category</label>
        <select name="type" class="form-select">
            <option value="">All Categories</option>
            <?php
            $typesList = ["Workshop","Seminar","Competition","Festival","Sport","Course"];
            foreach ($typesList as $t):
            ?>
                <option value="<?= $t ?>" <?= $type === $t ? 'selected' : '' ?>>
                    <?= $t ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="col-md-2 d-grid align-items-end">
    <button type="submit" class="btn btn-primary">
        Generate Report
    </button>
</div>

<div class="col-md-3 d-grid align-items-end">
    <a href="export_pdf.php?month=<?= $month ?>&type=<?= $type ?>"
       class="btn btn-outline-danger">
        🧾 Export PDF
    </a>
</div>


</form>

<!-- =========================
     REPORT TABLE
========================= -->
<?php if ($result->num_rows === 0): ?>
    <div class="alert alert-warning">
        No events found for the selected criteria.
    </div>
<?php else: ?>

<table class="table table-bordered table-striped shadow-sm">
<thead class="table-dark">
<tr>
<th>#</th>
<th>Event</th>
<th>Category</th>
<th>Date</th>
<th>Registered</th>
<th>Attended</th>
<th>Status</th>
</tr>
</thead>
<tbody>

<?php
$i = 1;
$today = date('Y-m-d');
while ($row = $result->fetch_assoc()):
$status = ($row['event_date'] < $today) ? "Done" : "Ongoing";
$statusBadge = ($status === "Done") ? "success" : "warning";
?>
<tr>
<td><?= $i++ ?></td>
<td><?= htmlspecialchars($row['event_name']) ?></td>
<td><?= $row['type'] ?></td>
<td><?= $row['event_date'] ?></td>
<td><?= $row['total_registered'] ?></td>
<td><?= $row['total_attended'] ?></td>
<td>
    <span class="badge bg-<?= $statusBadge ?>">
        <?= $status ?>
    </span>
</td>
</tr>
<?php endwhile; ?>

</tbody>
</table>

<?php endif; ?>

<a href="admin.php" class="btn btn-secondary mt-3">
⬅ Back to Admin Dashboard
</a>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
