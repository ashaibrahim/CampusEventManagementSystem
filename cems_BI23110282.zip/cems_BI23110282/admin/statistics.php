<?php
session_start();
require_once "../config/session_timeout.php";

/* 🔒 MUST BE LOGGED IN */
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

/* 🔒 MUST BE ADMIN */
if ($_SESSION['role'] !== 'admin') {
    http_response_code(403);
    die("⛔ Access Denied. Admins only.");
}

require_once "../config/db.php";

/* =========================
   FETCH OVERALL STATISTICS
========================= */
$totalUsers = $conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0];
$totalEvents = $conn->query("SELECT COUNT(*) FROM events")->fetch_row()[0];
$totalParticipants = $conn->query("SELECT COUNT(*) FROM registrations")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Overall Statistics | CEMS</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- KEEP ORIGINAL THEME -->
<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">

    <h3 class="mb-4 system-title">📊 Overall System Statistics</h3>

    <div class="row">

        <!-- TOTAL USERS -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm text-center h-100">
                <div class="card-body">
                    <h5>Total Users</h5>
                    <h2 class="fw-bold text-success"><?= $totalUsers ?></h2>

                    <a href="users_overview.php"
                       class="btn btn-outline-success btn-sm mt-3">
                        View Details
                    </a>
                </div>
            </div>
        </div>

        <!-- TOTAL EVENTS -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm text-center h-100">
                <div class="card-body">
                    <h5>Total Events</h5>
                    <h2 class="fw-bold text-success"><?= $totalEvents ?></h2>

                    <a href="events_overview.php"
                       class="btn btn-outline-success btn-sm mt-3">
                        View Details
                    </a>
                </div>
            </div>
        </div>

        <!-- TOTAL PARTICIPANTS -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm text-center h-100">
                <div class="card-body">
                    <h5>Total Participants</h5>
                    <h2 class="fw-bold text-success"><?= $totalParticipants ?></h2>

                    <a href="participants_overview.php"
                       class="btn btn-outline-success btn-sm mt-3">
                        View Details
                    </a>
                </div>
            </div>
        </div>

    </div>

    <a href="admin.php" class="btn btn-outline-secondary mt-3">
        ⬅ Back to Admin Dashboard
    </a>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
