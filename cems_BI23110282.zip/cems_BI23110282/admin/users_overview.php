<?php
session_start();
require_once "../config/session_timeout.php";
require_once "../config/db.php";

/* ADMIN ONLY */
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("⛔ Access Denied");
}

$roleFilter = $_GET['role'] ?? 'all';

$sql = "SELECT id, name, email, role, created_at FROM users";
if ($roleFilter !== 'all') {
    $sql .= " WHERE role = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $roleFilter);
} else {
    $stmt = $conn->prepare($sql);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
<title>Total Users | Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">
<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">
<h3>👥 All Users</h3>

<form class="row g-2 mb-3">
    <div class="col-md-3">
        <select name="role" class="form-select" onchange="this.form.submit()">
            <option value="all">All Roles</option>
            <?php foreach (['public','student','staff','admin'] as $r): ?>
                <option value="<?= $r ?>" <?= $roleFilter==$r?'selected':'' ?>>
                    <?= ucfirst($r) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
</form>

<table class="table table-bordered table-striped">
<thead class="table-dark">
<tr>
<th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Joined</th>
</tr>
</thead>
<tbody>
<?php $i=1; while($u=$result->fetch_assoc()): ?>
<tr>
<td><?= $i++ ?></td>
<td><?= htmlspecialchars($u['name']) ?></td>
<td><?= htmlspecialchars($u['email']) ?></td>
<td><?= ucfirst($u['role']) ?></td>
<td><?= $u['created_at'] ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</body>
</html>
