<?php
session_start();
require_once "../config/db.php";

$error = "";

/* =========================
   HANDLE LOGIN SUBMISSION
========================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {

        $sql = "SELECT * FROM users WHERE email = ? LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {

            $user = $result->fetch_assoc();

            /*  Check account status */
            if ($user['status'] === 'suspended') {
                $error = "Your account has been suspended. Please contact admin.";
            }
            /*  Verify password */
            elseif (password_verify($password, $user['password'])) {

                // STORE SESSION
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name']    = $user['name'];
                $_SESSION['email']   = $user['email'];
                $_SESSION['role']    = $user['role'];

                //  SESSION TIMER
                $_SESSION['LAST_ACTIVITY'] = time();

                /*  ROLE-BASED REDIRECTION */
                if ($user['role'] === 'admin') {
                    header("Location: ../admin/admin.php");
                } else {
                    header("Location: ../dashboard/index.php");
                }
                exit();

            } else {
                $error = "Invalid email or password.";
            }

        } else {
            $error = "Invalid email or password.";
        }

        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>EventRia | Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

<div class="text-center mt-4 mb-4">
    <img src="../images/header-logo.png" style="height:120px;" class="mb-3">
    <div class="system-title">
        <div class="system-title-main">EventRia</div>
        <div class="system-title-sub">Campus Event</div>
    </div>
</div>

<div class="container mb-5">
<div class="row justify-content-center">
<div class="col-md-5">

<div class="card shadow-sm">
<div class="card-body">

<h5 class="text-center mb-4">User Login</h5>

<?php if (!empty($error)): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST">

<div class="mb-3">
<label>Email</label>
<input type="email" name="email" class="form-control" required>
</div>

<div class="mb-3">
<label>Password</label>
<input type="password" name="password" class="form-control" required>
</div>

<div class="d-grid">
<button class="btn btn-primary">Login</button>
</div>

</form>

<p class="text-center mt-3">
Don’t have an account? <a href="register.php">Register</a>
</p>

</div>
</div>

</div>
</div>
</div>

</body>
</html>
