<?php
session_start();
require_once "../config/db.php";

/* Check request */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: login.php");
    exit();
}

/* Get input */
$email = trim($_POST['email']);
$password = $_POST['password'];

/* Check email exists */
$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

/* If user not found */
if ($result->num_rows !== 1) {
    $_SESSION['login_error'] = "Invalid email or password.";
    header("Location: login.php");
    exit();
}

$user = $result->fetch_assoc();

/* Verify password */
if (!password_verify($password, $user['password'])) {
    $_SESSION['login_error'] = "Invalid email or password.";
    header("Location: login.php");
    exit();
}

/* Login success → store session */
$_SESSION['user_id'] = $user['id'];
$_SESSION['name']    = $user['name'];
$_SESSION['role']    = $user['role'];

/* Redirect to dashboard */
header("Location: ../dashboard/index.php");
exit();
