<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>EventRia | Registration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Sage Green Theme -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<!-- HEADER LOGO + TITLE -->
<div class="text-center mt-4 mb-4">
    <img src="../images/header-logo.png"
         alt="CEMS Logo"
         style="height:120px;"
         class="mb-3">

    <div class="system-title">
        <div class="system-title-main">EventRia</div>
        <div class="system-title-sub">Campus Event</div>
    </div>
</div>

<div class="container mt-4 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-6">

            <div class="card shadow-sm">
                <div class="card-body">

                    <h5 class="text-center mb-4">User Registration</h5>

                    <?php
                    if (isset($_SESSION['register_error'])) {
                        echo "<div class='alert alert-danger'>" . $_SESSION['register_error'] . "</div>";
                        unset($_SESSION['register_error']);
                    }

                    if (isset($_SESSION['register_success'])) {
                        echo "<div class='alert alert-success'>" . $_SESSION['register_success'] . "</div>";
                        unset($_SESSION['register_success']);
                    }
                    ?>

                    <form action="register_action.php" method="POST" id="registerForm">

                        <!-- USER CATEGORY -->
                        <div class="mb-3">
                            <label class="form-label">Register As</label><br>
                            <input type="radio" name="role" value="student" required> Student
                            <input type="radio" name="role" value="staff" class="ms-3"> Staff
                            <input type="radio" name="role" value="public" class="ms-3"> Public
                        </div>

                        <!-- NAME -->
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>

                        <!-- EMAIL -->
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>

                        <!-- PHONE -->
                        <div class="mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-control" required>
                        </div>

                        <!-- RECOMMENDED EVENTS -->
                        <div class="mb-3">
                            <label class="form-label">
                                Recommended Events <small>(Select at least ONE)</small>
                            </label><br>
                            <input type="checkbox" name="recommend[]" value="Workshop"> Workshop<br>
                            <input type="checkbox" name="recommend[]" value="Seminar"> Seminar<br>
                            <input type="checkbox" name="recommend[]" value="Competition"> Competition<br>
                            <input type="checkbox" name="recommend[]" value="Festival"> Festival<br>
                            <input type="checkbox" name="recommend[]" value="Sport"> Sport<br>
                            <input type="checkbox" name="recommend[]" value="Course"> Course
                        </div>

                        <!-- PASSWORD -->
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" id="password" class="form-control" required>
                        </div>

                        <!-- CONFIRM PASSWORD -->
                        <div class="mb-3">
                            <label class="form-label">Confirm Password</label>
                            <input type="password" id="confirm_password" class="form-control" required>
                        </div>

                        <p id="errorMsg" class="text-danger"></p>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">
                                Register
                            </button>
                        </div>

                        <p class="mt-3 text-center">
                            Already have an account?
                            <a href="login.php">Login here</a>
                        </p>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

<!-- JS VALIDATION -->
<script>
document.getElementById("registerForm").addEventListener("submit", function(e) {

    const checkboxes = document.querySelectorAll('input[name="recommend[]"]');
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm_password").value;
    const errorMsg = document.getElementById("errorMsg");

    let checked = false;
    for (let box of checkboxes) {
        if (box.checked) {
            checked = true;
            break;
        }
    }

    if (!checked) {
        e.preventDefault();
        errorMsg.textContent = "Please select at least one recommended event.";
        return;
    }

    if (password !== confirmPassword) {
        e.preventDefault();
        errorMsg.textContent = "Passwords do not match.";
        return;
    }

    errorMsg.textContent = "";
});
</script>

</body>
</html>
