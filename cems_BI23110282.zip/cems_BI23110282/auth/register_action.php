<?php
session_start();
require_once "../config/db.php";

/* =========================
   1. CHECK REQUEST METHOD
========================= */
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: register.php");
    exit();
}

/* =========================
   2. GET & SANITIZE INPUT
========================= */
$role  = $_POST['role'] ?? '';
$name  = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$recommend = $_POST['recommend'] ?? [];
$password = $_POST['password'] ?? '';

/* =========================
   3. SERVER-SIDE VALIDATION
========================= */
$errors = [];

if (empty($role) || !in_array($role, ['student','staff','public'])) {
    $errors[] = "Invalid user role.";
}

if (empty($name)) {
    $errors[] = "Name is required.";
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Invalid email format.";
}

if (empty($phone)) {
    $errors[] = "Phone number is required.";
}

if (strlen($password) < 6) {
    $errors[] = "Password must be at least 6 characters.";
}

if (count($recommend) < 1) {
    $errors[] = "Please select at least one recommended event.";
}

if (!empty($errors)) {
    $_SESSION['register_error'] = implode("<br>", $errors);
    header("Location: register.php");
    exit();
}

/* =========================
   4. CHECK DUPLICATE EMAIL
========================= */
$checkSql = "SELECT id FROM users WHERE email = ?";
$stmt = $conn->prepare($checkSql);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $_SESSION['register_error'] = "Email already registered.";
    header("Location: register.php");
    exit();
}
$stmt->close();

/* =========================
   5. HASH PASSWORD
========================= */
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

/* =========================
   6. PREPARE DATA
========================= */
$recommendStr = implode(", ", $recommend);

/* =========================
   7. INSERT INTO DATABASE
========================= */
$sql = "INSERT INTO users 
(role, name, email, phone, recommend_events, password)
VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "ssssss",
    $role,
    $name,
    $email,
    $phone,
    $recommendStr,
    $hashedPassword
);

if ($stmt->execute()) {
    $_SESSION['register_success'] = "Registration successful! Please login.";
    header("Location: login.php");
} else {
    $_SESSION['register_error'] = "Registration failed. Try again.";
    header("Location: register.php");
}

$stmt->close();
$conn->close();
?>
