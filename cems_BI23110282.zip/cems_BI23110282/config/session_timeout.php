<?php
// Session timeout duration (30 minutes)
$timeout_duration = 1800;

// If last activity is set
if (isset($_SESSION['LAST_ACTIVITY'])) {

    // Check if session has expired
    if (time() - $_SESSION['LAST_ACTIVITY'] > $timeout_duration) {

        // Destroy session
        session_unset();
        session_destroy();

        // Redirect with timeout message
        header("Location: ../auth/login.php?timeout=1");
        exit();
    }
}

// Update last activity time
$_SESSION['LAST_ACTIVITY'] = time();
