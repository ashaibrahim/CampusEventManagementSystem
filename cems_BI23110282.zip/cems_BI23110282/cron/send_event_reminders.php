<?php
require_once __DIR__ . "/../config/db.php";

$tomorrow = date('Y-m-d');

/* Prevent running multiple times per day */
$check = $conn->prepare("
    SELECT 1 FROM notifications
    WHERE type = 'reminder'
      AND sent_date = ?
    LIMIT 1
");
$check->bind_param("s", $tomorrow);
$check->execute();
$alreadySent = $check->get_result()->num_rows > 0;
$check->close();

if ($alreadySent) {
    return;
}

/* Fetch approved participants */
$stmt = $conn->prepare("
    SELECT r.user_id, e.event_name, e.event_date
    FROM registrations r
    JOIN events e ON r.event_id = e.id
    WHERE e.event_date = DATE_ADD(CURDATE(), INTERVAL 1 DAY)
      AND r.status = 'approved'
");
$stmt->execute();
$result = $stmt->get_result();

/* Send notifications */
while ($row = $result->fetch_assoc()) {

    $notif = $conn->prepare("
        INSERT INTO notifications (user_id, title, message, type, sent_date)
        VALUES (?, ?, ?, 'reminder', ?)
    ");

    $title = "Event Reminder ⏰";
    $msg   = "Reminder: '{$row['event_name']}' is happening tomorrow ({$row['event_date']}).";
    $today = date('Y-m-d');

    $notif->bind_param("isss", $row['user_id'], $title, $msg, $today);
    $notif->execute();
    $notif->close();
}
