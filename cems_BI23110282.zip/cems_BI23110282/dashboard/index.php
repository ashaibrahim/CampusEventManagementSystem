<?php
session_start();
require_once "../config/session_timeout.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

require_once "../config/db.php";

$user_id = $_SESSION['user_id'];
$role    = $_SESSION['role']; // staff | student | public

/* =========================
   FILTER & SEARCH INPUTS
========================= */
$search    = $_GET['search'] ?? '';
$type      = $_GET['type'] ?? '';
$date      = $_GET['date'] ?? '';
$organizer = $_GET['organizer'] ?? '';

/* =========================
   BUILD SQL DYNAMICALLY
========================= */
$conditions = [];
$params     = [];
$types      = "";

/* ONLY APPROVED EVENTS */
$conditions[] = "status = 'approved'";

/* VISIBILITY RULE
   Public → public events only
   Staff/Student → all approved events
*/
if (!in_array($role, ['student', 'staff'])) {
    $conditions[] = "visibility = 'public'";
}

/* SEARCH */
if (!empty($search)) {
    $conditions[] = "(event_name LIKE ? OR organizer LIKE ? OR venue LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $types   .= "sss";
}

/* CATEGORY */
if (!empty($type)) {
    $conditions[] = "type = ?";
    $params[] = $type;
    $types   .= "s";
}

/* DATE */
if (!empty($date)) {
    $conditions[] = "event_date = ?";
    $params[] = $date;
    $types   .= "s";
}

/* ORGANIZER */
if (!empty($organizer)) {
    $conditions[] = "organizer LIKE ?";
    $params[] = "%$organizer%";
    $types   .= "s";
}

/* =========================
   FINAL SQL
========================= */
$sql = "SELECT * FROM events";

if ($conditions) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

$sql .= " ORDER BY event_date ASC";

$stmt = $conn->prepare($sql);

if ($params) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$events = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>User Dashboard | EventRia</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">

<h3 class="mb-2">
Welcome, <?= htmlspecialchars($_SESSION['name']) ?> 👋
</h3>

<p class="text-muted mb-4">
Role:
<span class="badge 
<?= $role=='staff' ? 'bg-primary' : ($role=='student' ? 'bg-info text-dark' : 'bg-secondary') ?>">
<?= ucfirst($role) ?>
</span>
</p>

<!-- QUICK ACTION CARDS -->
<div class="row mb-5 g-4">

<?php if (in_array($role, ['staff', 'student'])): ?>
    <!-- CREATE EVENT (Staff & Student only) -->
    <div class="col-md-6">
        <a href="../event/create.php" class="text-decoration-none">
            <div class="card shadow-lg border-0 create-event-card h-100">
                <div class="card-body d-flex align-items-center p-4">
                    <div class="me-4 fs-1 text-success">➕</div>
                    <div>
                        <h4 class="fw-bold mb-1 text-dark">Create New Event</h4>
                        <p class="text-muted mb-0">Organize workshops, seminars & more</p>
                    </div>
                </div>
            </div>
        </a>
    </div>
<?php endif; ?>

    <!-- REGISTERED EVENTS -->
    <div class="col-md-6">
        <a href="../dashboard/registrations.php" class="text-decoration-none">
            <div class="card shadow-lg border-0 registered-event-card h-100">
                <div class="card-body d-flex align-items-center p-4">
                    <div class="me-4 fs-1 text-primary">📌</div>
                    <div>
                        <h4 class="fw-bold mb-1 text-dark">Registered Events</h4>
                        <p class="text-muted mb-0">See the events you’re participating in</p>
                    </div>
                </div>
            </div>
        </a>
    </div>

</div>

<h4 class="mb-4">📅 Available Events</h4>

<!-- SEARCH & FILTER -->
<div class="card shadow-sm mb-4 border-0">
    <div class="card-body py-3">
        <form method="GET" class="row g-2 align-items-center">

            <div class="col-md-4">
                <input type="text" name="search"
                       value="<?= htmlspecialchars($search) ?>"
                       class="form-control form-control-sm"
                       placeholder="🔍 Search events">
            </div>

            <div class="col-md-3">
                <select name="type" class="form-select form-select-sm">
                    <option value="">All Categories</option>
                    <?php
                    $typesList = ["Workshop","Seminar","Competition","Festival","Sport","Course"];
                    foreach ($typesList as $t):
                    ?>
                    <option value="<?= $t ?>" <?= $type==$t?'selected':'' ?>>
                        <?= $t ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2">
                <button class="btn btn-success btn-sm w-100">
                    Apply
                </button>
            </div>

        </form>
    </div>
</div>

<?php if ($events->num_rows === 0): ?>
<div class="alert alert-warning">
No approved events available.
</div>
<?php endif; ?>

<div class="row">
<?php while ($event = $events->fetch_assoc()): ?>

<div class="col-md-4 mb-4">
<div class="card shadow-sm h-100">

<img src="../uploads/<?= htmlspecialchars($event['poster']) ?>"
     class="card-img-top"
     style="height:200px; object-fit:cover;">

<div class="card-body">

<h5><?= htmlspecialchars($event['event_name']) ?></h5>

<span class="badge <?= $event['visibility']=='university'?'bg-warning text-dark':'bg-success' ?>">
<?= $event['visibility']=='university'?'🏫 University Only':'🌍 Public' ?>
</span>

<p class="mt-2"><strong>Date:</strong> <?= $event['event_date'] ?></p>
<p><strong>Type:</strong> <?= $event['type'] ?></p>
<p><strong>Organizer:</strong> <?= htmlspecialchars($event['organizer']) ?></p>

<div class="d-grid gap-2">
<a href="../event/view.php?id=<?= $event['id'] ?>"
   class="btn btn-outline-secondary btn-sm">
View Details
</a>

<a href="../event/register.php?id=<?= $event['id'] ?>"
   class="btn btn-primary btn-sm">
Register
</a>
</div>

</div>
</div>
</div>

<?php endwhile; ?>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
