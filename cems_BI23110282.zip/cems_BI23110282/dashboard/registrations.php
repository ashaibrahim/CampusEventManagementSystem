<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once "../config/db.php";

$user_id = $_SESSION['user_id'];

$sql = "
    SELECT 
        e.id AS event_id,
        e.event_name,
        e.event_date,
        e.venue,
        e.mode,
        IFNULL(r.status, 'pending') AS status
    FROM registrations r
    JOIN events e ON r.event_id = e.id
    WHERE r.user_id = ?
    ORDER BY e.event_date ASC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Registered Events | EventRia</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">

<h3 class="mb-4">📌 My Registered Events</h3>

<?php if ($result->num_rows === 0): ?>
<div class="alert alert-info">You have not registered for any events yet.</div>
<?php else: ?>

<table class="table table-bordered table-striped align-middle">
<thead class="table-dark">
<tr>
<th>Event</th>
<th>Date</th>
<th>Venue</th>
<th>Mode</th>
<th>Status</th>
<th style="width:220px">Action</th>
</tr>
</thead>
<tbody>

<?php while ($row = $result->fetch_assoc()):
    $status = strtolower(trim($row['status']));
?>
<tr>
<td><?= htmlspecialchars($row['event_name']) ?></td>
<td><?= $row['event_date'] ?></td>
<td><?= htmlspecialchars($row['venue']) ?></td>
<td><?= ucfirst($row['mode']) ?></td>

<td>
<?php if ($status === 'approved'): ?>
<span class="badge bg-success">Approved</span>
<?php elseif ($status === 'rejected'): ?>
<span class="badge bg-danger">Rejected</span>
<?php else: ?>
<span class="badge bg-warning text-dark">Pending</span>
<?php endif; ?>
</td>

<td class="d-flex gap-2">
<a href="../event/view.php?id=<?= $row['event_id'] ?>"
   class="btn btn-sm btn-outline-secondary">
View
</a>

<?php if ($status !== 'rejected'): ?>
<a href="../event/unregister.php?id=<?= $row['event_id'] ?>"
   class="btn btn-sm btn-outline-danger"
   onclick="return confirm('Are you sure you want to unregister from this event?');">
Unregister
</a>
<?php endif; ?>
</td>

</tr>
<?php endwhile; ?>

</tbody>
</table>
<?php endif; ?>

<a href="../dashboard/index.php" class="btn btn-secondary mt-3">⬅ Back</a>

</div>
</body>
</html>
