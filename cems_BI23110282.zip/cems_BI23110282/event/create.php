<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once "../config/db.php";

$message = "";

/* =========================
   HANDLE FORM SUBMISSION
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {

    /* SAFE INPUT */
    $user_id         = $_SESSION['user_id'];
    $event_name      = $_POST['event_name'] ?? '';
    $description     = $_POST['description'] ?? '';
    $organizer       = $_POST['organizer'] ?? '';
    $contact_person  = $_POST['contact_person'] ?? '';
    $contact_no      = $_POST['contact_no'] ?? '';
    $type            = $_POST['type'] ?? '';
    $venue           = $_POST['venue'] ?? '';
    $event_date      = $_POST['event_date'] ?? '';
    $event_time      = $_POST['event_time'] ?? '';
    $mode            = $_POST['mode'] ?? '';
    $max_participant = $_POST['max_participant'] ?: null;
    $fee             = $_POST['fee'] ?? '';
    $remarks         = $_POST['remarks'] ?? '';
    $visibility      = $_POST['visibility'] ?? 'public';
    $status          = 'pending';

    /* =========================
       POSTER UPLOAD
    ========================= */
    if (!isset($_FILES['poster']) || $_FILES['poster']['error'] !== 0) {
        $message = "<div class='alert alert-danger'>❌ Poster upload failed</div>";
    } else {

        $poster_name = time() . "_" . basename($_FILES['poster']['name']);
        $target = "../uploads/" . $poster_name;

        if (!move_uploaded_file($_FILES['poster']['tmp_name'], $target)) {
            $message = "<div class='alert alert-danger'>❌ Failed to save poster</div>";
        }
    }

    /* =========================
       INSERT EVENT
    ========================= */
    if ($message === "") {

        $sql = "INSERT INTO events (
                    user_id, event_name, description, organizer,
                    contact_person, contact_no, type, venue,
                    event_date, event_time, mode,
                    max_participant, fee, remarks,
                    poster, visibility, status
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param(
            "issssssssssisssss",
            $user_id,
            $event_name,
            $description,
            $organizer,
            $contact_person,
            $contact_no,
            $type,
            $venue,
            $event_date,
            $event_time,
            $mode,
            $max_participant,
            $fee,
            $remarks,
            $poster_name,
            $visibility,
            $status
        );

        if ($stmt->execute()) {
            $message = "
            <div class='alert alert-success'>
                ✅ Event submitted successfully.<br>
                ⏳ Waiting for admin approval.
            </div>";
        } else {
            $message = "
            <div class='alert alert-danger'>
                ❌ Database error: {$stmt->error}
            </div>";
        }
// notify admin about new event approval request
$admins = $conn->query("SELECT id FROM users WHERE role = 'admin'");

while ($a = $admins->fetch_assoc()) {
    $stmtN = $conn->prepare("
        INSERT INTO notifications (user_id, title, message, type)
        VALUES (?, ?, ?, 'approval')
    ");

    $title = "New Event Pending Approval";
    $msg   = "Event '{$event_name}' is waiting for approval.";

    $stmtN->bind_param("iss", $a['id'], $title, $msg);
    $stmtN->execute();
}

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Create Event | CEMS</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5 mb-5">
<div class="row justify-content-center">
<div class="col-lg-8">

<div class="card shadow-sm">
<div class="card-body">

<h3 class="text-center mb-4 system-title">➕ Create New Event</h3>

<?= $message ?>

<form method="POST" enctype="multipart/form-data">

<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Event Name</label>
<input type="text" name="event_name" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label class="form-label">Organizer</label>
<input type="text" name="organizer" class="form-control" required>
</div>
</div>

<div class="mb-3">
<label class="form-label">Description</label>
<textarea name="description" class="form-control" rows="3" required></textarea>
</div>

<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Contact Person</label>
<input type="text" name="contact_person" class="form-control">
</div>

<div class="col-md-6 mb-3">
<label class="form-label">Contact Number</label>
<input type="text" name="contact_no" class="form-control">
</div>
</div>

<div class="row">
<div class="col-md-4 mb-3">
<label class="form-label">Event Type</label>
<select name="type" class="form-select" required>
<option value="">Select Type</option>
<option>Workshop</option>
<option>Seminar</option>
<option>Competition</option>
<option>Festival</option>
<option>Sport</option>
<option>Course</option>
</select>
</div>

<div class="col-md-4 mb-3">
<label class="form-label">Mode</label>
<select name="mode" class="form-select" required>
<option value="">Select Mode</option>
<option>physical</option>
<option>online</option>
<option>hybrid</option>
</select>
</div>

<div class="col-md-4 mb-3">
<label class="form-label">Venue</label>
<input type="text" name="venue" class="form-control" required>
</div>
</div>

<div class="row">
<div class="col-md-4 mb-3">
<label class="form-label">Event Date</label>
<input type="date" name="event_date" class="form-control" required>
</div>

<div class="col-md-4 mb-3">
<label class="form-label">Event Time</label>
<input type="time" name="event_time" class="form-control" required>
</div>

<div class="col-md-4 mb-3">
<label class="form-label">Max Participants</label>
<input type="number" name="max_participant" class="form-control">
</div>
</div>

<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Fee</label>
<input type="text" name="fee" class="form-control">
</div>

<div class="col-md-6 mb-3">
<label class="form-label">Poster</label>
<input type="file" name="poster" class="form-control" accept="image/*" required>
</div>
</div>

<div class="mb-3">
<label class="form-label">Event Visibility</label>
<select name="visibility" class="form-select" required>
<option value="public">🌍 Public</option>
<option value="university">🏫 University Only</option>
</select>
</div>

<div class="mb-3">
<label class="form-label">Remarks</label>
<textarea name="remarks" class="form-control" rows="2"></textarea>
</div>

<div class="d-grid gap-2 mt-4">
<button type="submit" name="submit" class="btn btn-primary">
Create Event
</button>
<a href="../dashboard/index.php" class="btn btn-outline-secondary">
⬅ Back
</a>
</div>

</form>

</div>
</div>

</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
