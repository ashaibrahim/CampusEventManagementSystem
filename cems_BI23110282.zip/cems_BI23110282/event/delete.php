<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once "../config/db.php";

$event_id = $_GET['id'] ?? 0;
$user_id  = $_SESSION['user_id'];

/* Fetch event to verify ownership */
$stmt = $conn->prepare(
    "SELECT user_id FROM events WHERE id = ?"
);
$stmt->bind_param("i", $event_id);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();

/* Access control */
if (!$event || $event['user_id'] != $user_id) {
    die("Access denied");
}

/* BEGIN TRANSACTION */
$conn->begin_transaction();

try {

    /* 1️⃣ DELETE REGISTRATIONS FIRST */
    $stmt = $conn->prepare(
        "DELETE FROM registrations WHERE event_id = ?"
    );
    $stmt->bind_param("i", $event_id);
    $stmt->execute();

    /* 2️⃣ DELETE EVENT */
    $stmt = $conn->prepare(
        "DELETE FROM events WHERE id = ?"
    );
    $stmt->bind_param("i", $event_id);
    $stmt->execute();

    /* COMMIT */
    $conn->commit();

    header("Location: my_events.php");
    exit;

} catch (Exception $e) {

    /* ROLLBACK IF ERROR */
    $conn->rollback();
    die("Failed to delete event.");

}
