<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once "../config/db.php";

$user_id = $_SESSION['user_id'];
$id      = (int)($_GET['id'] ?? 0);

/* =========================
   FETCH EVENT
========================= */
$stmt = $conn->prepare("
    SELECT * FROM events 
    WHERE id = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* ACCESS CONTROL */
if (!$event || $event['user_id'] != $user_id) {
    die("Access denied");
}

$message = "";

/* =========================
   HANDLE UPDATE
========================= */
if (isset($_POST['update'])) {

    $event_name        = $_POST['event_name'];
    $description       = $_POST['description'];
    $organizer         = $_POST['organizer'];
    $contact_person    = $_POST['contact_person'];
    $contact_no        = $_POST['contact_no'];
    $type              = $_POST['type'];
    $venue             = $_POST['venue'];
    $event_date        = $_POST['event_date'];
    $event_time        = $_POST['event_time'];
    $mode              = $_POST['mode'];
    $max_participant   = $_POST['max_participant'];
    $fee               = $_POST['fee'];
    $remarks           = $_POST['remarks'];

    /* Optional poster update */
    if (!empty($_FILES['poster']['name'])) {
        $poster_name = time() . "_" . basename($_FILES['poster']['name']);
        move_uploaded_file(
            $_FILES['poster']['tmp_name'],
            "../uploads/" . $poster_name
        );
    } else {
        $poster_name = $event['poster'];
    }

    /* UPDATE EVENT */
    $stmt = $conn->prepare("
        UPDATE events SET
            event_name=?, description=?, organizer=?, contact_person=?, contact_no=?,
            type=?, venue=?, event_date=?, event_time=?, mode=?,
            max_participant=?, fee=?, remarks=?, poster=?
        WHERE id=?
    ");

    $stmt->bind_param(
        "ssssssssssisssi",
        $event_name,
        $description,
        $organizer,
        $contact_person,
        $contact_no,
        $type,
        $venue,
        $event_date,
        $event_time,
        $mode,
        $max_participant,
        $fee,
        $remarks,
        $poster_name,
        $id
    );

    if ($stmt->execute()) {

        /* =========================
           NOTIFY APPROVED PARTICIPANTS
        ========================= */
        $participants = $conn->prepare("
            SELECT user_id 
            FROM registrations
            WHERE event_id = ? AND status = 'approved'
        ");
        $participants->bind_param("i", $id);
        $participants->execute();
        $result = $participants->get_result();

        while ($p = $result->fetch_assoc()) {

            $notif = $conn->prepare("
                INSERT INTO notifications (user_id, title, message, type)
                VALUES (?, ?, ?, 'update')
            ");

            $title = "Event Updated ✏️";
            $msg   = "Details for '{$event_name}' have been updated.";

            $notif->bind_param("iss", $p['user_id'], $title, $msg);
            $notif->execute();
            $notif->close();
        }

        $participants->close();

        header("Location: my_events.php");
        exit;

    } else {
        $message = "❌ Failed to update event";
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Event | EventRia</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5 mb-5">

<h3 class="mb-4 system-title">✏️ Edit Event</h3>

<div class="card shadow-sm">
<div class="card-body">

<?php if ($message): ?>
<div class="alert alert-danger"><?= $message ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">

<div class="mb-3">
<label class="form-label">Event Name</label>
<input type="text" name="event_name" class="form-control"
       value="<?= htmlspecialchars($event['event_name']) ?>" required>
</div>

<div class="mb-3">
<label class="form-label">Description</label>
<textarea name="description" class="form-control" rows="3" required><?= htmlspecialchars($event['description']) ?></textarea>
</div>

<div class="mb-3">
<label class="form-label">Organizer</label>
<input type="text" name="organizer" class="form-control"
       value="<?= htmlspecialchars($event['organizer']) ?>" required>
</div>

<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Contact Person</label>
<input type="text" name="contact_person" class="form-control"
       value="<?= htmlspecialchars($event['contact_person']) ?>">
</div>

<div class="col-md-6 mb-3">
<label class="form-label">Contact Number</label>
<input type="text" name="contact_no" class="form-control"
       value="<?= htmlspecialchars($event['contact_no']) ?>">
</div>
</div>

<div class="mb-3">
<label class="form-label">Event Type</label>
<select name="type" class="form-select" required>
<?php
$types = ["Workshop","Seminar","Competition","Festival","Sport","Course"];
foreach ($types as $t):
?>
<option <?= $event['type']===$t?'selected':'' ?>><?= $t ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="mb-3">
<label class="form-label">Venue</label>
<input type="text" name="venue" class="form-control"
       value="<?= htmlspecialchars($event['venue']) ?>" required>
</div>

<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Event Date</label>
<input type="date" name="event_date" class="form-control"
       value="<?= $event['event_date'] ?>" required>
</div>

<div class="col-md-6 mb-3">
<label class="form-label">Event Time</label>
<input type="time" name="event_time" class="form-control"
       value="<?= $event['event_time'] ?>" required>
</div>
</div>

<div class="mb-3">
<label class="form-label">Mode</label>
<select name="mode" class="form-select" required>
<option value="physical" <?= $event['mode']=="physical"?"selected":"" ?>>Physical</option>
<option value="online" <?= $event['mode']=="online"?"selected":"" ?>>Online</option>
<option value="hybrid" <?= $event['mode']=="hybrid"?"selected":"" ?>>Hybrid</option>
</select>
</div>

<div class="row">
<div class="col-md-6 mb-3">
<label class="form-label">Max Participants</label>
<input type="number" name="max_participant" class="form-control"
       value="<?= $event['max_participant'] ?>">
</div>

<div class="col-md-6 mb-3">
<label class="form-label">Fee</label>
<input type="text" name="fee" class="form-control"
       value="<?= htmlspecialchars($event['fee']) ?>" required>
</div>
</div>

<div class="mb-3">
<label class="form-label">Remarks</label>
<textarea name="remarks" class="form-control" rows="2"><?= htmlspecialchars($event['remarks']) ?></textarea>
</div>

<div class="mb-3">
<label class="form-label">Current Poster</label><br>
<img src="../uploads/<?= htmlspecialchars($event['poster']) ?>" width="160" class="rounded shadow-sm">
</div>

<div class="mb-4">
<label class="form-label">Change Poster (optional)</label>
<input type="file" name="poster" class="form-control" accept="image/*">
</div>

<div class="d-flex gap-2">
<button type="submit" name="update" class="btn btn-primary">💾 Update Event</button>
<a href="my_events.php" class="btn btn-outline-secondary">⬅ Back</a>
</div>

</form>

</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
