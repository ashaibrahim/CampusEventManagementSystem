<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['user_id'])) {
    die("Please login.");
}

$user_id  = $_SESSION['user_id'];
$event_id = (int)$_GET['event_id'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Event Feedback</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-body">

            <h4 class="mb-3">⭐ Rate This Event</h4>

            <form method="POST" action="submit_feedback.php">

                <input type="hidden" name="event_id" value="<?= $event_id ?>">

                <div class="mb-3">
                    <label class="form-label">Rating</label>
                    <select name="rating" class="form-select" required>
                        <option value="">Select</option>
                        <option value="5">⭐⭐⭐⭐⭐ Excellent</option>
                        <option value="4">⭐⭐⭐⭐ Good</option>
                        <option value="3">⭐⭐⭐ Average</option>
                        <option value="2">⭐⭐ Poor</option>
                        <option value="1">⭐ Very Poor</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Feedback (Optional)</label>
                    <textarea name="feedback" class="form-control" rows="4"></textarea>
                </div>

                <button class="btn btn-success">Submit Feedback</button>
            </form>

        </div>
    </div>
</div>

</body>
</html>
