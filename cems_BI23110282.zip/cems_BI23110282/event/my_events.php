<?php
session_start();

/* =========================
   AUTH & ROLE PROTECTION
========================= */
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

if (!in_array($_SESSION['role'], ['staff', 'student'])) {
    header("Location: ../dashboard/index.php");
    exit();
}

require_once "../config/db.php";

$user_id = $_SESSION['user_id'];

/* =========================
   FETCH USER EVENTS
========================= */
$stmt = $conn->prepare("
    SELECT *
    FROM events
    WHERE user_id = ?
    ORDER BY event_date DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Events | EventRia</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Theme -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5 mb-5">

    <h3 class="mb-4 system-title">
        📌 My Created Events
    </h3>

    <?php if ($result->num_rows === 0): ?>
        <div class="alert alert-info">
            You have not created any events yet.
        </div>
    <?php else: ?>

        <div class="card shadow-sm border-0">
            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-bordered align-middle themed-table">

                        <thead class="table-light">
                            <tr>
                                <th>Poster</th>
                                <th>Event Name</th>
                                <th>Date</th>
                                <th style="width: 280px;">Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <img src="../uploads/<?= htmlspecialchars($row['poster']) ?>"
                                         width="90"
                                         class="rounded shadow-sm"
                                         alt="Event Poster">
                                </td>

                                <td class="fw-semibold">
                                    <?= htmlspecialchars($row['event_name']) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($row['event_date']) ?>
                                </td>

                                <td>
                                    <div class="d-flex gap-2 flex-wrap">

                                        <a href="edit.php?id=<?= $row['id'] ?>"
                                           class="btn btn-sm btn-outline-primary">
                                            ✏️ Edit
                                        </a>

                                        <a href="participants.php?event_id=<?= $row['id'] ?>"
                                           class="btn btn-sm btn-outline-success">
                                            👥 Participants
                                        </a>

                                        <a href="delete.php?id=<?= $row['id'] ?>"
                                           class="btn btn-sm btn-outline-danger"
                                           onclick="return confirm('Delete this event?')">
                                            🗑 Delete
                                        </a>

                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>

                    </table>
                </div>

            </div>
        </div>

    <?php endif; ?>

    <a href="../dashboard/index.php" class="btn btn-outline-secondary mt-4">
        ⬅ Back to Dashboard
    </a>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
