<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once "../config/db.php";

$user_id  = $_SESSION['user_id'];
$event_id = (int)($_GET['event_id'] ?? 0);

if ($event_id <= 0) {
    die("Invalid event.");
}

/* =========================
   VERIFY EVENT OWNERSHIP
========================= */
$check = $conn->prepare("
    SELECT id, event_name 
    FROM events 
    WHERE id = ? AND user_id = ?
");
$check->bind_param("ii", $event_id, $user_id);
$check->execute();
$event = $check->get_result()->fetch_assoc();
$check->close();

if (!$event) {
    die("Access denied.");
}

$event_name = $event['event_name'];

/* =========================
   HANDLE ACTIONS
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['reg_id'])) {

    $reg_id = (int)$_POST['reg_id'];
    $action = $_POST['action'];

    /* Get participant user_id */
    $getUser = $conn->prepare("
        SELECT user_id 
        FROM registrations 
        WHERE id = ? AND event_id = ?
    ");
    $getUser->bind_param("ii", $reg_id, $event_id);
    $getUser->execute();
    $reg = $getUser->get_result()->fetch_assoc();
    $getUser->close();

    if (!$reg) {
        header("Location: participants.php?event_id=$event_id");
        exit;
    }

    $participant_id = $reg['user_id'];

    /* =========================
       APPROVE / REJECT
    ========================= */
    if ($action === 'approve') {

        $stmt = $conn->prepare("
            UPDATE registrations 
            SET status = 'approved' 
            WHERE id = ?
        ");
        $stmt->bind_param("i", $reg_id);
        $stmt->execute();
        $stmt->close();

        /* Notify participant */
        $notif = $conn->prepare("
            INSERT INTO notifications (user_id, title, message, type)
            VALUES (?, ?, ?, 'registration')
        ");

        $title = "Registration Approved 🎉";
        $msg   = "Your registration for '{$event_name}' has been approved.";

        $notif->bind_param("iss", $participant_id, $title, $msg);
        $notif->execute();
        $notif->close();
    }

    if ($action === 'reject') {

        $stmt = $conn->prepare("
            UPDATE registrations 
            SET status = 'rejected' 
            WHERE id = ?
        ");
        $stmt->bind_param("i", $reg_id);
        $stmt->execute();
        $stmt->close();

        /* Notify participant */
        $notif = $conn->prepare("
            INSERT INTO notifications (user_id, title, message, type)
            VALUES (?, ?, ?, 'registration')
        ");

        $title = "Registration Rejected ❌";
        $msg   = "Your registration for '{$event_name}' has been rejected.";

        $notif->bind_param("iss", $participant_id, $title, $msg);
        $notif->execute();
        $notif->close();
    }

    /* =========================
       ATTENDANCE
    ========================= */
    if ($action === 'present' || $action === 'absent') {

        $stmt = $conn->prepare("
            UPDATE registrations 
            SET attendance = ? 
            WHERE id = ?
        ");
        $stmt->bind_param("si", $action, $reg_id);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: participants.php?event_id=" . $event_id);
    exit;
}

/* =========================
   EXPORT CSV
========================= */
if (isset($_GET['export']) && $_GET['export'] === 'csv') {

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="participants.csv"');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['Name', 'Email', 'Status', 'Attendance']);

    $export = $conn->prepare("
        SELECT u.name, u.email, r.status, r.attendance
        FROM registrations r
        JOIN users u ON r.user_id = u.id
        WHERE r.event_id = ?
    ");
    $export->bind_param("i", $event_id);
    $export->execute();
    $res = $export->get_result();

    while ($row = $res->fetch_assoc()) {
        fputcsv($out, $row);
    }

    fclose($out);
    exit;
}

/* =========================
   FETCH PARTICIPANTS
========================= */
$stmt = $conn->prepare("
    SELECT r.id AS reg_id, u.name, u.email, r.status, r.attendance
    FROM registrations r
    JOIN users u ON r.user_id = u.id
    WHERE r.event_id = ?
");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Participants | EventRia</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">

<h3 class="mb-3">
👥 Participants — <?= htmlspecialchars($event_name) ?>
</h3>

<a href="?event_id=<?= $event_id ?>&export=csv" class="btn btn-success mb-3">
⬇ Export CSV
</a>

<?php if ($result->num_rows === 0): ?>
<div class="alert alert-warning">No participants yet.</div>
<?php else: ?>

<table class="table table-bordered table-striped align-middle">
<thead class="table-dark">
<tr>
<th>#</th>
<th>Name</th>
<th>Email</th>
<th>Status</th>
<th>Attendance</th>
<th style="width:230px">Actions</th>
</tr>
</thead>

<tbody>
<?php $i=1; while ($row = $result->fetch_assoc()): ?>
<tr>
<td><?= $i++ ?></td>
<td><?= htmlspecialchars($row['name']) ?></td>
<td><?= htmlspecialchars($row['email']) ?></td>

<td>
<span class="badge bg-<?=
$row['status']=='approved'?'success':
($row['status']=='rejected'?'danger':'warning') ?>">
<?= ucfirst($row['status']) ?>
</span>
</td>

<td><?= ucfirst($row['attendance'] ?? '-') ?></td>

<td>
<form method="POST"
      action="participants.php?event_id=<?= $event_id ?>"
      class="d-flex gap-1">

<input type="hidden" name="reg_id" value="<?= $row['reg_id'] ?>">

<?php if ($row['status'] === 'pending'): ?>
<button name="action" value="approve" class="btn btn-sm btn-success">Approve</button>
<button name="action" value="reject" class="btn btn-sm btn-danger">Reject</button>
<?php endif; ?>

<?php if ($row['status'] === 'approved'): ?>
<button name="action" value="present" class="btn btn-sm btn-primary">Present</button>
<button name="action" value="absent" class="btn btn-sm btn-secondary">Absent</button>
<?php endif; ?>

</form>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>

<?php endif; ?>

<a href="my_events.php" class="btn btn-secondary mt-3">
⬅ Back to My Events
</a>

</div>
</body>
</html>
