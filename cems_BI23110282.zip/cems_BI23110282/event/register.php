<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once "../config/db.php";

$user_id  = $_SESSION['user_id'];
$event_id = (int)($_GET['id'] ?? 0);

/* =========================
   FETCH EVENT
========================= */
$stmt = $conn->prepare("
    SELECT id, event_name, user_id 
    FROM events 
    WHERE id = ?
");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$event) {
    die("Event not found.");
}

$event_name = $event['event_name'];
$creator_id = $event['user_id'];

/* =========================
   BLOCK EVENT CREATOR
========================= */
$isCreator = ($creator_id == $user_id);

/* =========================
   CHECK REGISTRATION
========================= */
$check = $conn->prepare("
    SELECT 1 
    FROM registrations
    WHERE user_id = ? AND event_id = ?
    LIMIT 1
");
$check->bind_param("ii", $user_id, $event_id);
$check->execute();
$alreadyRegistered = $check->get_result()->num_rows > 0;
$check->close();

$error = "";

/* =========================
   HANDLE REGISTRATION
========================= */
if (isset($_POST['confirm_register']) && !$alreadyRegistered && !$isCreator) {

    $insert = $conn->prepare("
        INSERT INTO registrations (user_id, event_id, status)
        VALUES (?, ?, 'pending')
    ");
    $insert->bind_param("ii", $user_id, $event_id);

    if ($insert->execute()) {

        /* =========================
           NOTIFY EVENT CREATOR
        ========================= */
        $notif = $conn->prepare("
            INSERT INTO notifications (user_id, title, message, type)
            VALUES (?, ?, ?, 'registration')
        ");

        $title   = "New Participant Registered 👤";
        $message = "A new participant has registered for your event '{$event_name}'.";

        $notif->bind_param("iss", $creator_id, $title, $message);
        $notif->execute();
        $notif->close();

        $_SESSION['register_success'] =
            "You have successfully registered for <strong>" .
            htmlspecialchars($event_name) .
            "</strong>.";

        header("Location: ../dashboard/index.php");
        exit;

    } else {
        $error = "❌ Registration failed. Please try again.";
    }

    $insert->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register Event | EventRia</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">
<div class="row justify-content-center">
<div class="col-md-6">

<div class="card shadow-sm">
<div class="card-body text-center">

<h4 class="system-title mb-3">Event Registration</h4>

<p class="fs-5 fw-semibold">
    <?= htmlspecialchars($event_name) ?>
</p>

<?php if ($isCreator): ?>
    <div class="alert alert-danger">
        ❌ You cannot register for an event you created.
    </div>

<?php elseif ($alreadyRegistered): ?>
    <div class="alert alert-warning">
        ⚠ You are already registered for this event.
    </div>

<?php else: ?>
    <p class="text-muted mb-4">
        Are you sure you want to register for this event?
    </p>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <button type="submit"
                name="confirm_register"
                class="btn btn-primary me-2">
            ✅ Yes, Register Me
        </button>

        <a href="../dashboard/index.php"
           class="btn btn-outline-secondary">
            Cancel
        </a>
    </form>
<?php endif; ?>

</div>
</div>

</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
