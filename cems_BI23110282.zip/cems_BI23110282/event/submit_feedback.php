<?php
session_start();
require_once "../config/db.php";

$user_id  = $_SESSION['user_id'];
$event_id = (int)$_POST['event_id'];
$rating   = (int)$_POST['rating'];
$feedback = trim($_POST['feedback']);

// Save feedback
$stmt = $conn->prepare("
    INSERT INTO event_feedback (event_id, user_id, rating, feedback)
    VALUES (?, ?, ?, ?)
");
$stmt->bind_param("iiis", $event_id, $user_id, $rating, $feedback);
$stmt->execute();
$stmt->close();

// Get organizer
$event = $conn->query("
    SELECT user_id, event_name 
    FROM events 
    WHERE id = $event_id
")->fetch_assoc();

// Send notification
$title   = "New Event Feedback ⭐";
$message = "Your event '{$event['event_name']}' received a $rating-star rating.";

$stmt = $conn->prepare("
    INSERT INTO notifications (user_id, title, message, type)
    VALUES (?, ?, ?, 'feedback')
");
$stmt->bind_param("iss", $event['user_id'], $title, $message);
$stmt->execute();

header("Location: ../dashboard/index.php");
exit;
