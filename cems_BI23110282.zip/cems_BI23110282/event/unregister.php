<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

$user_id  = $_SESSION['user_id'];
$event_id = intval($_GET['id'] ?? 0);

if (!$event_id) {
    die("Invalid event.");
}

/* CHECK REGISTRATION */
$stmt = $conn->prepare(
    "SELECT status FROM registrations WHERE user_id = ? AND event_id = ?"
);
$stmt->bind_param("ii", $user_id, $event_id);
$stmt->execute();
$reg = $stmt->get_result()->fetch_assoc();

if (!$reg) {
    die("Not registered.");
}

$status = strtolower(trim($reg['status']));

/* BLOCK ONLY IF REJECTED */
if ($status === 'rejected') {
    die("You cannot unregister from a rejected registration.");
}

/* DELETE REGISTRATION */
$delete = $conn->prepare(
    "DELETE FROM registrations WHERE user_id = ? AND event_id = ?"
);
$delete->bind_param("ii", $user_id, $event_id);
$delete->execute();

header("Location: ../dashboard/registrations.php");
exit;
