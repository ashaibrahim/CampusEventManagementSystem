<?php
session_start();
require_once "../config/db.php";

$id = $_GET['id'] ?? 0;

$stmt = $conn->prepare("SELECT * FROM events WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();

if (!$event) {
    die("Event not found");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($event['event_name']) ?> | Event Details</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5">

    <div class="card shadow-sm">
        <img src="../uploads/<?= htmlspecialchars($event['poster']) ?>"
             class="card-img-top"
             style="max-height:350px; object-fit:cover;">

        <div class="card-body">
            <h3 class="mb-3"><?= htmlspecialchars($event['event_name']) ?></h3>

            <p><strong>Description:</strong><br>
                <?= nl2br(htmlspecialchars($event['description'])) ?>
            </p>

            <p><strong>Organizer:</strong> <?= htmlspecialchars($event['organizer']) ?></p>
            <p><strong>Contact Person:</strong> <?= htmlspecialchars($event['contact_person']) ?></p>
            <p><strong>Contact No:</strong> <?= htmlspecialchars($event['contact_no']) ?></p>
            <p><strong>Type:</strong> <?= htmlspecialchars($event['type']) ?></p>
            <p><strong>Venue:</strong> <?= htmlspecialchars($event['venue']) ?></p>
            <p><strong>Date:</strong> <?= $event['event_date'] ?></p>
            <p><strong>Time:</strong> <?= $event['event_time'] ?></p>
            <p><strong>Mode:</strong> <?= ucfirst($event['mode']) ?></p>
            <p><strong>Max Participants:</strong> <?= $event['max_participant'] ?></p>
            <p><strong>Fee:</strong> <?= htmlspecialchars($event['fee']) ?></p>

            <?php if (!empty($event['remarks'])): ?>
                <p><strong>Remarks:</strong><br>
                    <?= nl2br(htmlspecialchars($event['remarks'])) ?>
                </p>
            <?php endif; ?>

            <div class="d-flex gap-2 mt-4">
                <a href="register.php?id=<?= $event['id'] ?>"
                   class="btn btn-primary">
                    Register
                </a>

                <a href="../dashboard/index.php"
                   class="btn btn-secondary">
                    ⬅ Back
                </a>
            </div>

        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
