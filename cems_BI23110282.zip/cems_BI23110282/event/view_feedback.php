<?php
session_start();
require_once "../config/db.php";

$event_id = (int)$_GET['event_id'];

$feedbacks = $conn->query("
    SELECT u.name, f.rating, f.feedback, f.created_at
    FROM event_feedback f
    JOIN users u ON u.id = f.user_id
    WHERE f.event_id = $event_id
    ORDER BY f.created_at DESC
");
?>

<div class="container mt-4">
    <h4>📊 Event Feedback</h4>

    <?php while ($f = $feedbacks->fetch_assoc()): ?>
        <div class="card mb-3 shadow-sm">
            <div class="card-body">
                <strong><?= htmlspecialchars($f['name']) ?></strong>
                <span class="text-warning ms-2">
                    <?= str_repeat("⭐", $f['rating']) ?>
                </span>
                <p class="mt-2"><?= nl2br(htmlspecialchars($f['feedback'])) ?></p>
                <small class="text-muted">
                    <?= date('d M Y', strtotime($f['created_at'])) ?>
                </small>
            </div>
        </div>
    <?php endwhile; ?>
</div>
