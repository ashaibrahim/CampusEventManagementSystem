<?php
session_start();
require_once "config/db.php";

/* =========================
   FILTER & SEARCH INPUTS
========================= */
$search    = $_GET['search'] ?? '';
$type      = $_GET['type'] ?? '';
$date      = $_GET['date'] ?? '';
$organizer = $_GET['organizer'] ?? '';

/* =========================
   BUILD SQL (PUBLIC ONLY)
========================= */
$conditions = ["visibility = 'public'"];
$params     = [];
$types      = "";

/* Search */
if (!empty($search)) {
    $conditions[] = "(event_name LIKE ? OR organizer LIKE ? OR venue LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $types   .= "sss";
}

/* Category */
if (!empty($type)) {
    $conditions[] = "type = ?";
    $params[] = $type;
    $types   .= "s";
}

/* Date */
if (!empty($date)) {
    $conditions[] = "event_date = ?";
    $params[] = $date;
    $types   .= "s";
}

/* Organizer */
if (!empty($organizer)) {
    $conditions[] = "organizer LIKE ?";
    $params[] = "%$organizer%";
    $types   .= "s";
}

$sql = "SELECT * FROM events WHERE " . implode(" AND ", $conditions) . " ORDER BY event_date ASC";

$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Campus Events | EventRia</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">

<!-- =====================
     GUEST NAVBAR
====================== -->
<nav class="navbar navbar-expand-lg navbar-dark bg-success shadow-sm">
<div class="container">

<a class="navbar-brand d-flex align-items-center" href="index.php">
    <img src="images/header-logo.png"
         style="height:45px;"
         class="me-2">
    <span class="fw-bold fs-6 text-white">EventRia</span>
</a>

<button class="navbar-toggler border-0 p-2"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#guestNavbar">
    <span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="guestNavbar">
<ul class="navbar-nav ms-auto align-items-center gap-2 gap-lg-0">

<li class="nav-item ms-3">
<a href="auth/register.php" class="btn btn-success px-4">Get Started</a>
</li>

<li class="nav-item ms-2">
<a href="auth/login.php" class="btn btn-outline-light px-4">Login</a>
</li>

</ul>
</div>

</div>
</nav>

<!-- ===================== HERO ====================== -->
<section class="py-5 bg-white border-bottom">
<div class="container text-center">
<h1 class="fw-bold mb-3">Discover, Join & Create Campus Events 🎉</h1>
<p class="text-muted fs-5 mb-4">
From workshops and seminars to competitions and festivals —
<br class="d-none d-md-block">
manage and explore all campus events in one simple platform.
</p>
<div class="d-flex justify-content-center gap-3">
<a href="auth/register.php" class="btn btn-success btn-lg px-5">Get Started</a>
<button class="btn btn-outline-secondary btn-lg px-5" onclick="showLoginAlert()">
Join Event
</button>
</div>
</div>
</section>

<!-- ===================== FILTER ====================== -->
<div class="container mt-5">

<h2 class="mb-4 text-center">📅 Upcoming Public Events</h2>

<div class="card shadow-sm mb-4">
<div class="card-body">

<form method="GET" class="row g-3">

<div class="col-md-4">
<input type="text"
       name="search"
       value="<?= htmlspecialchars($search) ?>"
       class="form-control"
       placeholder="🔍 Search events">
</div>

<div class="col-md-2">
<select name="type" class="form-select">
<option value="">All Categories</option>
<?php
$typesList = ["Workshop","Seminar","Competition","Festival","Sport","Course"];
foreach ($typesList as $t):
?>
<option value="<?= $t ?>" <?= $type==$t?'selected':'' ?>>
<?= $t ?>
</option>
<?php endforeach; ?>
</select>
</div>

<div class="col-md-2 d-grid">
<button class="btn btn-primary">Apply</button>
</div>

</form>

</div>
</div>

<?php if ($result->num_rows === 0): ?>
<div class="alert alert-warning text-center">
No events match your search.
</div>
<?php endif; ?>

<div class="row">
<?php while ($row = $result->fetch_assoc()): ?>
<div class="col-md-4 mb-4">
<div class="card shadow-sm h-100">

<img src="uploads/<?= htmlspecialchars($row['poster']) ?>"
     class="card-img-top"
     style="height:200px; object-fit:cover;">

<div class="card-body">
<h5><?= htmlspecialchars($row['event_name']) ?></h5>

<span class="badge bg-success">🌍 Public</span>

<p class="mt-2"><strong>Date:</strong> <?= $row['event_date'] ?></p>
<p><strong>Organizer:</strong> <?= htmlspecialchars($row['organizer']) ?></p>
<p><strong>Venue:</strong> <?= htmlspecialchars($row['venue']) ?></p>

<div class="d-grid gap-2">
    <!-- 🔍 VIEW DETAILS -->
    <a href="event/view.php?id=<?= $row['id'] ?>"
       class="btn btn-outline-secondary btn-sm">
        View Details
    </a>

    <!-- 🔐 REGISTER -->
    <button class="btn btn-primary btn-sm"
            onclick="showLoginAlert()">
        Register
    </button>
</div>

</div>
</div>
</div>
<?php endwhile; ?>
</div>

</div>

<footer class="text-center text-muted mt-5 mb-3">
EventRia © 2025
</footer>

<script>
function showLoginAlert() {
    alert("Please log in or register to continue.");
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
