<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Mark all notifications as read for this user
$stmt = $conn->prepare("
    UPDATE notifications
    SET is_read = 1
    WHERE user_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();

// Redirect back
header("Location: ../dashboard/index.php");
exit;
