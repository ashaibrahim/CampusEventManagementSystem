<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once "../config/db.php";

$role    = $_SESSION['role'] ?? 'public';   // staff | student | public | admin
$user_id = $_SESSION['user_id'] ?? null;

$notif  = null;
$unread = 0;

if ($user_id) {

    // Fetch latest notifications
    $stmt = $conn->prepare("
        SELECT id, title, message, is_read, created_at
        FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $notif = $stmt->get_result();

    // Count unread notifications
    $countStmt = $conn->prepare("
        SELECT COUNT(*) AS total
        FROM notifications
        WHERE user_id = ? AND is_read = 0
    ");
    $countStmt->bind_param("i", $user_id);
    $countStmt->execute();
    $unread = $countStmt->get_result()->fetch_assoc()['total'];
}
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-success shadow-sm">
<div class="container">

    <!-- LOGO -->
    <a class="navbar-brand d-flex align-items-center" href="../dashboard/index.php">
        <img src="../images/header-logo.png" alt="CEMS Logo" style="height:80px;" class="me-2">
        <span class="fw-bold fs-5">EventRia</span>
    </a>

    <button class="navbar-toggler" type="button"
            data-bs-toggle="collapse"
            data-bs-target="#mainNavbar">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="mainNavbar">
    <ul class="navbar-nav ms-auto align-items-lg-center">

        <!-- 🔔 NOTIFICATIONS -->
        <?php if ($user_id): ?>
        <li class="nav-item dropdown">
            <a class="nav-link position-relative d-flex align-items-center justify-content-center"
               href="#"
               role="button"
               data-bs-toggle="dropdown"
               style="
                   font-size: 1.6rem;
                   width: 42px;
                   height: 42px;
                   border-radius: 50%;
                   background: rgba(255,255,255,0.15);
               ">
                🔔
                <?php if ($unread > 0): ?>
                    <span class="badge bg-danger position-absolute top-0 start-100 translate-middle">
                        <?= $unread ?>
                    </span>
                <?php endif; ?>
            </a>

            <ul class="dropdown-menu dropdown-menu-end shadow"
                style="width:320px; max-height:400px; overflow-y:auto;">

                <li class="dropdown-header d-flex justify-content-between align-items-center">
                    <span class="fw-bold">Notifications</span>

                    <?php if ($unread > 0): ?>
                        <a href="../notification/read_all.php"
                           class="small text-decoration-none">
                            Mark all
                        </a>
                    <?php endif; ?>
                </li>

                <li><hr class="dropdown-divider"></li>

                <?php if ($notif->num_rows === 0): ?>
                    <li class="dropdown-item text-muted small text-center">
                        No notifications
                    </li>
                <?php endif; ?>

                <?php while ($n = $notif->fetch_assoc()): ?>
                    <li class="dropdown-item small <?= $n['is_read'] ? '' : 'bg-light' ?>"
                        style="cursor: default;">
                        <div class="fw-semibold">
                            <?= htmlspecialchars($n['title']) ?>
                        </div>
                        <div class="text-muted small">
                            <?= htmlspecialchars($n['message']) ?>
                        </div>
                        <div class="text-muted small">
                            <?= date('d M Y, h:i A', strtotime($n['created_at'])) ?>
                        </div>
                    </li>
                <?php endwhile; ?>

            </ul>
        </li>
        <?php endif; ?>

        <!-- ROLE-BASED MENU -->
        <?php if ($role === 'admin'): ?>

            <li class="nav-item">
                <a href="../admin/admin.php" class="nav-link fw-bold text-white">
                    Admin Dashboard
                </a>
            </li>

            <li class="nav-item">
                <a href="../admin/statistics.php" class="nav-link fw-bold text-white">
                    Overall Statistic
                </a>
            </li>

        <?php else: ?>

            <li class="nav-item">
                <a href="../dashboard/index.php" class="nav-link fw-bold text-white">
                    Dashboard
                </a>
            </li>

            <!-- MY EVENTS: Staff & Student ONLY -->
            <?php if (in_array($role, ['staff', 'student'])): ?>
            <li class="nav-item">
                <a href="../event/my_events.php" class="nav-link fw-bold text-white">
                    My Events
                </a>
            </li>
            <?php endif; ?>

            <li class="nav-item">
                <a href="../user/profile.php" class="nav-link fw-bold text-white">
                    My Profile
                </a>
            </li>

        <?php endif; ?>

        <!-- LOGOUT -->
        <?php if ($user_id): ?>
        <li class="nav-item ms-lg-3">
            <a href="../auth/logout.php" class="btn btn-outline-light btn-sm">
                Logout
            </a>
        </li>
        <?php endif; ?>

    </ul>
    </div>
</div>
</nav>
