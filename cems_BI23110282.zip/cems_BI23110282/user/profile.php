<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

require_once "../config/db.php";

$user_id = $_SESSION['user_id'];
$message = "";

/* =========================
   FETCH USER DATA
========================= */
$stmt = $conn->prepare(
    "SELECT name, email, phone, role, password FROM users WHERE id = ?"
);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* =========================
   UPDATE PROFILE (NAME + PHONE)
========================= */
if (isset($_POST['update_profile'])) {

    $name  = trim($_POST['name']);
    $phone = trim($_POST['phone']);

    if ($name === "" || $phone === "") {
        $message = "<div class='alert alert-danger'>All profile fields are required.</div>";
    } else {

        $update = $conn->prepare(
            "UPDATE users SET name = ?, phone = ? WHERE id = ?"
        );
        $update->bind_param("ssi", $name, $phone, $user_id);

        if ($update->execute()) {
            $_SESSION['name'] = $name;
            $message = "<div class='alert alert-success'>Profile updated successfully.</div>";
        } else {
            $message = "<div class='alert alert-danger'>Profile update failed.</div>";
        }

        $update->close();
    }
}

/* =========================
   UPDATE PASSWORD
========================= */
if (isset($_POST['update_password'])) {

    $current_password = $_POST['current_password'];
    $new_password     = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if (
        empty($current_password) ||
        empty($new_password) ||
        empty($confirm_password)
    ) {
        $message = "<div class='alert alert-danger'>All password fields are required.</div>";
    }
    elseif (!password_verify($current_password, $user['password'])) {
        $message = "<div class='alert alert-danger'>Current password is incorrect.</div>";
    }
    elseif ($new_password !== $confirm_password) {
        $message = "<div class='alert alert-danger'>New passwords do not match.</div>";
    }
    elseif (strlen($new_password) < 6) {
        $message = "<div class='alert alert-danger'>Password must be at least 6 characters.</div>";
    }
    else {

        $hashed = password_hash($new_password, PASSWORD_DEFAULT);

        $updatePass = $conn->prepare(
            "UPDATE users SET password = ? WHERE id = ?"
        );
        $updatePass->bind_param("si", $hashed, $user_id);

        if ($updatePass->execute()) {
            $message = "<div class='alert alert-success'>Password updated successfully.</div>";
        } else {
            $message = "<div class='alert alert-danger'>Failed to update password.</div>";
        }

        $updatePass->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Profile | EventRia</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<?php include "../partials/navbar.php"; ?>

<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-7">

            <div class="card shadow-sm">
                <div class="card-body">

                    <h4 class="text-center mb-4 system-title">
                        👤 My Profile
                    </h4>

                    <?= $message ?>

                    <!-- ================= PROFILE FORM ================= -->
                    <form method="POST" class="mb-4">

                        <h6 class="mb-3">Profile Information</h6>

                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text"
                                   name="name"
                                   class="form-control"
                                   value="<?= htmlspecialchars($user['name']) ?>"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email"
                                   class="form-control"
                                   value="<?= htmlspecialchars($user['email']) ?>"
                                   readonly>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="text"
                                   name="phone"
                                   class="form-control"
                                   value="<?= htmlspecialchars($user['phone']) ?>"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <input type="text"
                                   class="form-control"
                                   value="<?= ucfirst($user['role']) ?>"
                                   readonly>
                        </div>

                        <button type="submit"
                                name="update_profile"
                                class="btn btn-primary w-100">
                            Save Profile Changes
                        </button>
                    </form>

                    <hr>

                    <!-- ================= PASSWORD FORM ================= -->
                    <form method="POST">

                        <h6 class="mb-3">Change Password</h6>

                        <div class="mb-3">
                            <label class="form-label">Current Password</label>
                            <input type="password"
                                   name="current_password"
                                   class="form-control"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password"
                                   name="new_password"
                                   class="form-control"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password"
                                   name="confirm_password"
                                   class="form-control"
                                   required>
                        </div>

                        <button type="submit"
                                name="update_password"
                                class="btn btn-warning w-100">
                            🔒 Update Password
                        </button>
                    </form>

                    <a href="../dashboard/index.php"
                       class="btn btn-outline-secondary mt-3 w-100">
                        ⬅ Back to Dashboard
                    </a>

                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
